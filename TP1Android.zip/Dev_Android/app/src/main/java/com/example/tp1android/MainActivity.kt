package com.example.tp1android

import android.os.Bundle
import androidx.activity.ComponentActivity

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.tp1android.ui.theme.TP1AndroidTheme
import org.intellij.lang.annotations.JdkConstants.HorizontalAlignment

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TP1AndroidTheme {

                // A surface container using the 'background' color from the theme
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val windowSizeClass = calculateWindowSizeClass(this)
                    Screen()
                }
            }
        }
    }
}



@Composable
fun Screen() {
    Column (
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top,
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 100.dp)
        ){
        Greeting("Louna")
        ImageChat()
        Présentation()
        Démarrer()

    }
}


@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
            text = "Hello $name!",
            modifier = modifier
    )
}

@Composable
fun ImageChat() {
    Image(
        painterResource(id = R.drawable.suna),
        contentDescription = "chat",
        Modifier
            .clip(RoundedCornerShape(200.dp))
            .size(300.dp)
    )
}

@Composable
fun Présentation() {
    Column (horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "Suna Bashti"
        )
        Text(text = "Chat professionnel")
    }
    Column (modifier = Modifier.padding(40.dp)){
        Row {
            Image(
                painterResource(id = R.drawable.baseline_location_on_24),
                contentDescription = "location"
            )
            Text(text = "Sur le canapé")
        }
        Row {
            Image(
                painterResource(id = R.drawable.baseline_add_24),
                contentDescription = "add"
            )
            Text(text = "Ajouter en ami")
        }
    }

}

@Composable
fun Démarrer() {
    Button(onClick = { /*TODO*/ }, modifier = Modifier.clip(RoundedCornerShape(2.dp)),) {
        Text(text = "Démarrer")

    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    TP1AndroidTheme {
        Screen()
    }
}